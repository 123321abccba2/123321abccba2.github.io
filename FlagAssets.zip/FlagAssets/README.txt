[ENG]
Hello everyone! I'm Reff. If you need anything, or if there is something wrong with your purchase please contact me through any of the following means:

www.reffsq.com/Contact

Email: contactreff@gmail.com
Twitter: https://twitter.com/Reff_SQ
Itch.io: https://reff-sq.itch.io/
Reddit: https://www.reddit.com/user/_Reff/
Discord: Reff#5905

Welcome to Flag Assets! This is an asset pack wich contains multiple images in png format to use in any retro / pixel-art style project you are working on. These can be used for language icons, location, maps, and games in general.
Complete  with over 18 variations  for more than 200 flags of the world in pixel-art style. ( It also includes a bunch of animations! )
Every flag has been carefully crafted pixel by pixel. The designs are stylized, with vibrant colors and exagerated symbols in order to make them distinctive, but also feel like they belong in the same family. 


FLAGS INCLUDED (212):
� Full UN members list (193) 
� Observatory States of Vatican City, Taiwan and Palestine (3)
� European Union (1)
� r/Vexillology flag (Special thanks!) (1)
� Single Colors (14)

CONTENT LIST:
Icons: (All categories apply to full and simplified version of every flag)
� Rectangular Icons 48x32 
� Rectangular Icons 24x16
� Rectangular Icons 12x8 
� Square Icons 24x24
� Square Icons 16x16
� Square Icons 8x8 
� Circle Icons 24x24
� Circle Icons 16x16 
� Circle Icons 8x8

Animations: 

� Knight Flag waving gif (Only single color flags)
� Big flag loop (Only single color flags)
� Somalia flag animation (No variations)
� USA construction animation (No variations)
� Germany Stick-man Flag waving gif (No variations)

LICENCE: 
This asset pack can be used in both free and commercial projects. You can modify it to suit your own needs. Credit is unnecessary, but highly appreciated (@Reff_SQ).  
You may not redistribute, resell or take your own credit for this Asset Pack, a fraction of it, or a slightly modified version.